<?php
require 'koneksi.php';
$pesan = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    try {
        $st = $db->prepare("DELETE FROM produk WHERE id_produk=?");
        $st->bind_param('i', $id); $st->execute(); $pesan = 'Produk dihapus.';
    } catch (Exception $ex) { $pesan = 'Produk tidak bisa dihapus karena sudah ada di pesanan.'; }
}
$r = $db->query("SELECT p.*, k.nama_kategori, s.nama_toko FROM produk p
  JOIN kategori k ON k.id_kategori=p.id_kategori JOIN penjual s ON s.id_penjual=p.id_penjual ORDER BY p.id_produk DESC");
include 'header.php';
?>
<div class="d-flex justify-content-between mb-3"><h4>Kelola Produk</h4>
  <a href="produk_form.php" class="btn btn-dark">Tambah produk</a></div>
<?php if ($pesan) echo '<div class="alert alert-info">' . e($pesan) . '</div>'; ?>
<table class="table bg-white align-middle">
  <thead><tr><th>Nama</th><th>Kategori</th><th>Penjual</th><th>Harga</th><th>Stok</th><th></th></tr></thead>
  <?php while ($p = $r->fetch_assoc()): ?>
  <tr><td><?= e($p['nama_produk']) ?></td><td><?= e($p['nama_kategori']) ?></td><td><?= e($p['nama_toko']) ?></td>
    <td><?= rp($p['harga']) ?></td><td><?= $p['stok'] ?></td>
    <td class="d-flex gap-1"><a class="btn btn-sm btn-outline-dark" href="produk_form.php?id=<?= $p['id_produk'] ?>">Ubah</a>
      <form method="post" onsubmit="return confirm('Hapus produk ini?')"><input type="hidden" name="id" value="<?= $p['id_produk'] ?>">
      <button class="btn btn-sm btn-outline-danger">Hapus</button></form></td></tr>
  <?php endwhile; ?>
</table>
<?php include 'footer.php'; ?>

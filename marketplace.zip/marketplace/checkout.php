<?php
require 'koneksi.php';
$sukses = null; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_SESSION['cart']) {
    $db->begin_transaction();
    try {
        $st = $db->prepare("INSERT INTO pelanggan (nama,email,telepon,alamat) VALUES (?,?,?,?)");
        $st->bind_param('ssss', $_POST['nama'], $_POST['email'], $_POST['telepon'], $_POST['alamat']);
        $st->execute(); $idPel = $db->insert_id;

        $baris = []; $total = 0;
        foreach ($_SESSION['cart'] as $id => $jml) {
            $s = $db->prepare("SELECT harga, stok, nama_produk FROM produk WHERE id_produk=? FOR UPDATE");
            $s->bind_param('i', $id); $s->execute();
            $p = $s->get_result()->fetch_assoc();
            if (!$p || $p['stok'] < $jml) throw new Exception('Stok tidak cukup untuk ' . ($p['nama_produk'] ?? 'produk'));
            $baris[] = [$id, $jml, $p['harga']]; $total += $jml * $p['harga'];
        }
        $st = $db->prepare("INSERT INTO pesanan (id_pelanggan,total) VALUES (?,?)");
        $st->bind_param('id', $idPel, $total); $st->execute(); $idPes = $db->insert_id;

        foreach ($baris as [$id, $jml, $harga]) {
            $st = $db->prepare("INSERT INTO detail_pesanan (id_pesanan,id_produk,jumlah,harga_satuan) VALUES (?,?,?,?)");
            $st->bind_param('iiid', $idPes, $id, $jml, $harga); $st->execute();
            $st = $db->prepare("UPDATE produk SET stok=stok-? WHERE id_produk=?");
            $st->bind_param('ii', $jml, $id); $st->execute();
        }
        $db->commit(); $_SESSION['cart'] = []; $sukses = $idPes;
    } catch (Exception $ex) { $db->rollback(); $error = $ex->getMessage(); }
}
include 'header.php';
if ($sukses): ?>
  <div class="alert alert-success">Pesanan #<?= $sukses ?> berhasil dibuat. Terima kasih sudah berbelanja.</div>
  <a href="index.php" class="btn btn-dark">Kembali ke produk</a>
<?php elseif (!$_SESSION['cart']): ?>
  <div class="alert alert-info">Keranjang kosong. <a href="index.php">Pilih produk</a>.</div>
<?php else: ?>
  <h4>Data Pemesan</h4>
  <?php if ($error) echo '<div class="alert alert-danger">' . e($error) . '</div>'; ?>
  <form method="post" class="card card-body">
    <div class="mb-2"><label class="form-label">Nama</label><input name="nama" class="form-control" required></div>
    <div class="mb-2"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
    <div class="mb-2"><label class="form-label">Telepon</label><input name="telepon" class="form-control"></div>
    <div class="mb-3"><label class="form-label">Alamat pengiriman</label><textarea name="alamat" class="form-control" required></textarea></div>
    <button class="btn btn-dark">Simpan pesanan</button>
  </form>
<?php endif; include 'footer.php'; ?>

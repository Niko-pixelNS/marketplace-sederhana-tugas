<?php
require 'koneksi.php';
$q = '%' . ($_GET['q'] ?? '') . '%';
$st = $db->prepare("SELECT p.*, k.nama_kategori, s.nama_toko FROM produk p
  JOIN kategori k ON k.id_kategori=p.id_kategori
  JOIN penjual s ON s.id_penjual=p.id_penjual
  WHERE p.nama_produk LIKE ? ORDER BY p.id_produk DESC");
$st->bind_param('s', $q); $st->execute(); $r = $st->get_result();
include 'header.php';
?>
<form class="row g-2 mb-4" method="get">
  <div class="col"><input class="form-control" name="q" placeholder="Cari produk" value="<?= e($_GET['q'] ?? '') ?>"></div>
  <div class="col-auto"><button class="btn btn-dark">Cari</button></div>
</form>
<div class="row g-3">
<?php while ($p = $r->fetch_assoc()): ?>
  <div class="col-sm-6 col-lg-3"><div class="card h-100">
    <div class="card-body d-flex flex-column">
      <span class="badge text-bg-secondary align-self-start mb-2"><?= e($p['nama_kategori']) ?></span>
      <h6 class="card-title"><?= e($p['nama_produk']) ?></h6>
      <div class="text-muted small mb-2"><?= e($p['nama_toko']) ?></div>
      <div class="fw-bold mb-3"><?= rp($p['harga']) ?></div>
      <a href="produk.php?id=<?= $p['id_produk'] ?>" class="btn btn-outline-dark btn-sm mt-auto">Lihat detail</a>
    </div>
  </div></div>
<?php endwhile; ?>
</div>
<?php if ($r->num_rows === 0) echo '<p class="text-muted">Produk tidak ditemukan.</p>'; include 'footer.php'; ?>

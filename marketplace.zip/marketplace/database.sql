CREATE DATABASE IF NOT EXISTS marketplace CHARACTER SET utf8mb4;
USE marketplace;

CREATE TABLE penjual (
  id_penjual INT AUTO_INCREMENT PRIMARY KEY,
  nama_toko VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  telepon VARCHAR(20)
);
CREATE TABLE kategori (
  id_kategori INT AUTO_INCREMENT PRIMARY KEY,
  nama_kategori VARCHAR(50) NOT NULL
);
CREATE TABLE produk (
  id_produk INT AUTO_INCREMENT PRIMARY KEY,
  id_penjual INT NOT NULL,
  id_kategori INT NOT NULL,
  nama_produk VARCHAR(150) NOT NULL,
  deskripsi TEXT,
  harga DECIMAL(12,0) NOT NULL,
  stok INT NOT NULL DEFAULT 0,
  FOREIGN KEY (id_penjual) REFERENCES penjual(id_penjual),
  FOREIGN KEY (id_kategori) REFERENCES kategori(id_kategori)
);
CREATE TABLE pelanggan (
  id_pelanggan INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  telepon VARCHAR(20),
  alamat TEXT NOT NULL
);
CREATE TABLE pesanan (
  id_pesanan INT AUTO_INCREMENT PRIMARY KEY,
  id_pelanggan INT NOT NULL,
  tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
  total DECIMAL(12,0) NOT NULL,
  status VARCHAR(20) DEFAULT 'Baru',
  FOREIGN KEY (id_pelanggan) REFERENCES pelanggan(id_pelanggan)
);
CREATE TABLE detail_pesanan (
  id_detail INT AUTO_INCREMENT PRIMARY KEY,
  id_pesanan INT NOT NULL,
  id_produk INT NOT NULL,
  jumlah INT NOT NULL,
  harga_satuan DECIMAL(12,0) NOT NULL,
  FOREIGN KEY (id_pesanan) REFERENCES pesanan(id_pesanan) ON DELETE CASCADE,
  FOREIGN KEY (id_produk) REFERENCES produk(id_produk)
);

INSERT INTO penjual (nama_toko,email,telepon) VALUES
 ('Toko Bengkulu Jaya','jaya@example.com','081200000001'),
 ('Kopi Rafflesia','kopi@example.com','081200000002');
INSERT INTO kategori (nama_kategori) VALUES ('Makanan & Minuman'),('Fashion'),('Elektronik');
INSERT INTO produk (id_penjual,id_kategori,nama_produk,deskripsi,harga,stok) VALUES
 (2,1,'Kopi Robusta Kemumu 250g','Biji kopi sangrai dari dataran tinggi Bengkulu.',55000,40),
 (1,1,'Keripik Tempoyak','Camilan khas Bengkulu, renyah dan gurih.',25000,60),
 (1,2,'Kain Besurek Motif Rafflesia','Kain batik khas Bengkulu, ukuran 2 meter.',185000,15),
 (1,3,'Powerbank 10000 mAh','Powerbank ringkas dengan dua port USB.',120000,25);

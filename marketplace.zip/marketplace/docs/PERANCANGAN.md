# Dokumen Perancangan Web Marketplace

## A. Analisis dan Perancangan

### a. Entitas
1. **Penjual** - pemilik toko yang menawarkan produk.
2. **Kategori** - pengelompokan produk.
3. **Produk** - barang yang dijual.
4. **Pelanggan (Pembeli)** - pihak yang memesan.
5. **Pesanan** - transaksi pemesanan.
6. **Detail_Pesanan** - rincian produk pada setiap pesanan.

Keranjang belanja disimpan di session PHP (belum masuk database) dan baru disimpan sebagai Pesanan saat checkout.

### b. Rancangan Database

| Tabel | Atribut | PK | FK |
|---|---|---|---|
| penjual | id_penjual, nama_toko, email, telepon | id_penjual | - |
| kategori | id_kategori, nama_kategori | id_kategori | - |
| produk | id_produk, id_penjual, id_kategori, nama_produk, deskripsi, harga, stok | id_produk | id_penjual, id_kategori |
| pelanggan | id_pelanggan, nama, email, telepon, alamat | id_pelanggan | - |
| pesanan | id_pesanan, id_pelanggan, tanggal, total, status | id_pesanan | id_pelanggan |
| detail_pesanan | id_detail, id_pesanan, id_produk, jumlah, harga_satuan | id_detail | id_pesanan, id_produk |

Hubungan:
- Penjual 1 : N Produk
- Kategori 1 : N Produk
- Pelanggan 1 : N Pesanan
- Pesanan 1 : N Detail_Pesanan
- Produk 1 : N Detail_Pesanan (Pesanan dan Produk berhubungan N : M melalui Detail_Pesanan)

### c. ERD

```mermaid
erDiagram
  PENJUAL ||--o{ PRODUK : menjual
  KATEGORI ||--o{ PRODUK : mengelompokkan
  PELANGGAN ||--o{ PESANAN : membuat
  PESANAN ||--|{ DETAIL_PESANAN : memiliki
  PRODUK ||--o{ DETAIL_PESANAN : dipesan_dalam

  PENJUAL { int id_penjual PK
    string nama_toko
    string email
    string telepon }
  KATEGORI { int id_kategori PK
    string nama_kategori }
  PRODUK { int id_produk PK
    int id_penjual FK
    int id_kategori FK
    string nama_produk
    text deskripsi
    decimal harga
    int stok }
  PELANGGAN { int id_pelanggan PK
    string nama
    string email
    string telepon
    text alamat }
  PESANAN { int id_pesanan PK
    int id_pelanggan FK
    datetime tanggal
    decimal total
    string status }
  DETAIL_PESANAN { int id_detail PK
    int id_pesanan FK
    int id_produk FK
    int jumlah
    decimal harga_satuan }
```

### d. Alur Proses Transaksi

```mermaid
flowchart TD
  A[Pembeli membuka daftar produk] --> B[Memilih produk, lihat detail]
  B --> C[Tambah ke keranjang]
  C --> D{Belanja lagi?}
  D -- Ya --> A
  D -- Tidak --> E[Buka keranjang, cek jumlah]
  E --> F[Isi data pemesan]
  F --> G{Stok cukup?}
  G -- Tidak --> E
  G -- Ya --> H[Simpan pelanggan, pesanan, detail pesanan]
  H --> I[Kurangi stok produk]
  I --> J[Pesanan berhasil, keranjang dikosongkan]
```

### e. Mockup UI

**Daftar produk** (`index.php`)
```
+--------------------------------------------------+
| Marketplace      Produk  Kelola Produk  Keranjang(2) |
+--------------------------------------------------+
| [ Cari produk.............................] [Cari] |
| +----------+ +----------+ +----------+ +----------+
| | Kategori | | Kategori | | Kategori | | Kategori |
| | Nama     | | Nama     | | Nama     | | Nama     |
| | Toko     | | Toko     | | Toko     | | Toko     |
| | Rp 55.000| | Rp 25.000| |Rp185.000 | |Rp120.000 |
| |[Detail]  | |[Detail]  | |[Detail]  | |[Detail]  |
| +----------+ +----------+ +----------+ +----------+
+--------------------------------------------------+
```

**Detail produk** (`produk.php`)
```
+--------------------------------------------------+
| [Kategori]                                       |
| Kopi Robusta Kemumu 250g                         |
| Dijual oleh Kopi Rafflesia                       |
| Deskripsi produk ...                             |
| Rp 55.000        Stok: 40                        |
| [ Jumlah: 1 ]  [Tambah ke keranjang]             |
+--------------------------------------------------+
```

**Keranjang belanja** (`keranjang.php`)
```
+--------------------------------------------------+
| Keranjang Belanja                                |
| Produk        Harga    Jumlah       Subtotal     |
| Kopi Robusta  55.000   [2][Ubah]    110.000 [Hapus]|
| Keripik       25.000   [1][Ubah]     25.000 [Hapus]|
|                              Total:  135.000     |
| [Lanjut belanja]            [Buat pesanan]       |
+--------------------------------------------------+
```

## B. Implementasi
Teknologi: PHP Native, MySQLi (prepared statement), Bootstrap 5.

| File | Fungsi |
|---|---|
| `database.sql` | Struktur tabel dan data contoh |
| `index.php` | Daftar produk dan pencarian |
| `produk.php` | Detail produk, tambah ke keranjang |
| `admin_produk.php`, `produk_form.php` | CRUD produk (list, tambah, ubah, hapus) |
| `keranjang.php` | Kelola keranjang (tambah, ubah, hapus) |
| `checkout.php` | Simpan transaksi ke database (memakai transaksi SQL) |
| `koneksi.php`, `config.php` | Koneksi database |

Catatan: halaman kelola produk belum memakai login. Untuk penggunaan nyata, tambahkan autentikasi.

## C. Deployment dan GitHub

### Menjalankan lokal (XAMPP)
1. Salin folder proyek ke `htdocs/marketplace`.
2. Buka `http://localhost/phpmyadmin`, lalu import `database.sql`.
3. Buka `http://localhost/marketplace`.

### Deployment InfinityFree
1. Daftar di infinityfree.com, lalu buat akun hosting dan pilih subdomain.
2. Di *Control Panel*, buka **MySQL Databases**, buat database. Catat host (mis. `sqlXXX.infinityfree.com`), username, password, dan nama database.
3. Buka **phpMyAdmin**, pilih database tersebut, lalu import `database.sql`. Hapus baris `CREATE DATABASE` dan `USE marketplace;` sebelum import karena nama database dari InfinityFree sudah ditentukan.
4. Unggah semua file (kecuali `database.sql` dan folder `docs`, jika mau) ke folder `htdocs` lewat **File Manager** atau FTP.
5. Edit `config.php` di hosting, isi host, user, password, dan nama database dari langkah 2.
6. Buka subdomain Anda dan uji alur belanja.

### Publikasi GitHub
```bash
git init
git add .
git commit -m "Marketplace sederhana PHP"
git branch -M main
git remote add origin https://github.com/USERNAME/marketplace.git
git push -u origin main
```
`config.php` sudah masuk `.gitignore` sehingga password tidak ikut terunggah. Yang diunggah adalah `config.sample.php`.

### Daftar bukti untuk laporan
- URL demo: `https://NAMA.infinityfreeapp.com` (isi dengan milik Anda)
- URL GitHub: `https://github.com/USERNAME/marketplace` (isi dengan milik Anda)
- Screenshot: daftar produk, detail produk, keranjang, CRUD produk
- Screenshot struktur database di phpMyAdmin
- Screenshot hasil uji transaksi: tabel `pesanan` dan `detail_pesanan` terisi, `stok` pada `produk` berkurang

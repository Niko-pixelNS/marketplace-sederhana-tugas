<?php
require 'koneksi.php';
$id = (int)($_GET['id'] ?? 0);
$st = $db->prepare("SELECT p.*, k.nama_kategori, s.nama_toko FROM produk p
  JOIN kategori k ON k.id_kategori=p.id_kategori
  JOIN penjual s ON s.id_penjual=p.id_penjual WHERE p.id_produk=?");
$st->bind_param('i', $id); $st->execute();
$p = $st->get_result()->fetch_assoc();
include 'header.php';
if (!$p) { echo '<div class="alert alert-warning">Produk tidak ditemukan.</div>'; include 'footer.php'; exit; }
?>
<div class="card"><div class="card-body">
  <span class="badge text-bg-secondary"><?= e($p['nama_kategori']) ?></span>
  <h3 class="mt-2"><?= e($p['nama_produk']) ?></h3>
  <p class="text-muted">Dijual oleh <?= e($p['nama_toko']) ?></p>
  <p><?= nl2br(e($p['deskripsi'])) ?></p>
  <h4><?= rp($p['harga']) ?></h4>
  <p>Stok: <?= (int)$p['stok'] ?></p>
  <?php if ($p['stok'] > 0): ?>
  <form action="keranjang.php" method="post" class="row g-2">
    <input type="hidden" name="aksi" value="tambah">
    <input type="hidden" name="id" value="<?= $p['id_produk'] ?>">
    <div class="col-auto"><input type="number" name="jumlah" value="1" min="1" max="<?= $p['stok'] ?>" class="form-control"></div>
    <div class="col-auto"><button class="btn btn-dark">Tambah ke keranjang</button></div>
  </form>
  <?php else: ?><div class="alert alert-secondary">Stok habis.</div><?php endif; ?>
</div></div>
<?php include 'footer.php'; ?>

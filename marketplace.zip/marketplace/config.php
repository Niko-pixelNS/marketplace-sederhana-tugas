<?php
// Konfigurasi LOKAL (XAMPP). File ini TIDAK diunggah ke GitHub (lihat .gitignore).
// Untuk InfinityFree, ganti nilai di bawah sesuai panel hosting.
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'marketplace';

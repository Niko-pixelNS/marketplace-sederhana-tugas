</div>
<footer class="text-center text-muted small my-5">Marketplace sederhana - PHP Native, MySQLi, Bootstrap</footer>
</body></html>

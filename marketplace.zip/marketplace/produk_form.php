<?php
require 'koneksi.php';
$id = (int)($_GET['id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v = [$_POST['id_penjual'], $_POST['id_kategori'], $_POST['nama_produk'], $_POST['deskripsi'], $_POST['harga'], $_POST['stok']];
    if ($id) {
        $st = $db->prepare("UPDATE produk SET id_penjual=?, id_kategori=?, nama_produk=?, deskripsi=?, harga=?, stok=? WHERE id_produk=?");
        $st->bind_param('iissdii', $v[0], $v[1], $v[2], $v[3], $v[4], $v[5], $id);
    } else {
        $st = $db->prepare("INSERT INTO produk (id_penjual,id_kategori,nama_produk,deskripsi,harga,stok) VALUES (?,?,?,?,?,?)");
        $st->bind_param('iissdi', $v[0], $v[1], $v[2], $v[3], $v[4], $v[5]);
    }
    $st->execute(); header('Location: admin_produk.php'); exit;
}
$p = ['id_penjual'=>'', 'id_kategori'=>'', 'nama_produk'=>'', 'deskripsi'=>'', 'harga'=>'', 'stok'=>''];
if ($id) { $st = $db->prepare("SELECT * FROM produk WHERE id_produk=?"); $st->bind_param('i', $id); $st->execute(); $p = $st->get_result()->fetch_assoc() ?: $p; }
$penjual = $db->query("SELECT * FROM penjual"); $kat = $db->query("SELECT * FROM kategori");
include 'header.php';
?>
<h4><?= $id ? 'Ubah' : 'Tambah' ?> Produk</h4>
<form method="post" class="card card-body">
  <div class="mb-2"><label class="form-label">Nama produk</label><input name="nama_produk" class="form-control" value="<?= e($p['nama_produk']) ?>" required></div>
  <div class="row mb-2">
    <div class="col"><label class="form-label">Penjual</label><select name="id_penjual" class="form-select">
      <?php while ($s = $penjual->fetch_assoc()) echo '<option value="' . $s['id_penjual'] . '"' . ($s['id_penjual'] == $p['id_penjual'] ? ' selected' : '') . '>' . e($s['nama_toko']) . '</option>'; ?></select></div>
    <div class="col"><label class="form-label">Kategori</label><select name="id_kategori" class="form-select">
      <?php while ($k = $kat->fetch_assoc()) echo '<option value="' . $k['id_kategori'] . '"' . ($k['id_kategori'] == $p['id_kategori'] ? ' selected' : '') . '>' . e($k['nama_kategori']) . '</option>'; ?></select></div>
  </div>
  <div class="mb-2"><label class="form-label">Deskripsi</label><textarea name="deskripsi" class="form-control"><?= e($p['deskripsi']) ?></textarea></div>
  <div class="row mb-3">
    <div class="col"><label class="form-label">Harga (Rp)</label><input type="number" name="harga" class="form-control" value="<?= e($p['harga']) ?>" required></div>
    <div class="col"><label class="form-label">Stok</label><input type="number" name="stok" class="form-control" value="<?= e($p['stok']) ?>" required></div>
  </div>
  <div><button class="btn btn-dark">Simpan produk</button> <a href="admin_produk.php" class="btn btn-outline-secondary">Batal</a></div>
</form>
<?php include 'footer.php'; ?>

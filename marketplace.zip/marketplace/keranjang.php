<?php
require 'koneksi.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $aksi = $_POST['aksi'] ?? '';
    if ($aksi === 'tambah') {
        $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + max(1, (int)$_POST['jumlah']);
    } elseif ($aksi === 'ubah') {
        $j = (int)$_POST['jumlah'];
        if ($j > 0) $_SESSION['cart'][$id] = $j; else unset($_SESSION['cart'][$id]);
    } elseif ($aksi === 'hapus') {
        unset($_SESSION['cart'][$id]);
    }
    header('Location: keranjang.php'); exit;
}
$items = []; $total = 0;
foreach ($_SESSION['cart'] as $id => $jml) {
    $st = $db->prepare("SELECT id_produk, nama_produk, harga, stok FROM produk WHERE id_produk=?");
    $st->bind_param('i', $id); $st->execute();
    if ($p = $st->get_result()->fetch_assoc()) {
        $p['jumlah'] = min($jml, $p['stok']); $p['sub'] = $p['jumlah'] * $p['harga'];
        $total += $p['sub']; $items[] = $p;
    }
}
include 'header.php';
?>
<h4 class="mb-3">Keranjang Belanja</h4>
<?php if (!$items): ?>
  <div class="alert alert-info">Keranjang masih kosong. <a href="index.php">Pilih produk</a>.</div>
<?php else: ?>
<table class="table bg-white align-middle">
  <thead><tr><th>Produk</th><th>Harga</th><th width="150">Jumlah</th><th>Subtotal</th><th></th></tr></thead>
  <?php foreach ($items as $p): ?>
  <tr>
    <td><?= e($p['nama_produk']) ?></td><td><?= rp($p['harga']) ?></td>
    <td><form method="post" class="d-flex gap-1">
      <input type="hidden" name="aksi" value="ubah"><input type="hidden" name="id" value="<?= $p['id_produk'] ?>">
      <input type="number" name="jumlah" value="<?= $p['jumlah'] ?>" min="0" max="<?= $p['stok'] ?>" class="form-control form-control-sm">
      <button class="btn btn-sm btn-outline-dark">Ubah</button></form></td>
    <td><?= rp($p['sub']) ?></td>
    <td><form method="post"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= $p['id_produk'] ?>">
      <button class="btn btn-sm btn-outline-danger">Hapus</button></form></td>
  </tr>
  <?php endforeach; ?>
  <tr class="fw-bold"><td colspan="3" class="text-end">Total</td><td colspan="2"><?= rp($total) ?></td></tr>
</table>
<a href="index.php" class="btn btn-outline-secondary">Lanjut belanja</a>
<a href="checkout.php" class="btn btn-dark">Buat pesanan</a>
<?php endif; include 'footer.php'; ?>

<!DOCTYPE html>
<html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Marketplace Bengkulu</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<nav class="navbar navbar-expand navbar-dark bg-dark mb-4"><div class="container">
  <a class="navbar-brand" href="index.php">Marketplace</a>
  <div class="navbar-nav ms-auto">
    <a class="nav-link" href="index.php">Produk</a>
    <a class="nav-link" href="admin_produk.php">Kelola Produk</a>
    <a class="nav-link" href="keranjang.php">Keranjang (<?= array_sum($_SESSION['cart']) ?>)</a>
  </div>
</div></nav>
<div class="container">

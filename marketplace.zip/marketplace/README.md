# Marketplace Sederhana (PHP Native + MySQLi + Bootstrap)

1. Import `database.sql` ke MySQL.
2. Salin `config.sample.php` menjadi `config.php`, lalu isi kredensial database.
3. Buka `index.php` di browser.

Dokumen perancangan, ERD, dan mockup ada di `docs/PERANCANGAN.md`.

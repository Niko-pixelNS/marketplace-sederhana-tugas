<?php
// Salin file ini menjadi config.php lalu isi sesuai database Anda.
// Jangan commit config.php ke repository publik.
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'marketplace';
